using UnityEngine;

public class Centroid :  MonoBehaviour
{
    public bool isOccupied = false;
}
